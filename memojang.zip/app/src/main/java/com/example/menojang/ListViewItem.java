package com.example.menojang;

public class ListViewItem {

    String title;
    String time;
    String memo;

    public String getTitle() {
        return title;
    }
    public String getTime() {
        return time;
    }
    public String getMemo(){ return memo;}

    public void setName(String title) {
        this.title = title;
    }
    public void setTime(String time) {
        this.time = time;
    }
    public void setMemo(String memo) {
        this.memo = memo;
    }

}
